#Jquery MoverBoxes
jquery plugin that builds a list builder.

##Demo
*http://kgaddy.com/jqueryMoverBoxes/
